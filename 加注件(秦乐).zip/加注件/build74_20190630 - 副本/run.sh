#!/bin/bash
# 
# chmod +x ./run.sh
# nohup ./run.sh >/dev/null 2>&1 &
# cat pid
# kill -TERM pid

if [ ! -d "./logs" ]; then
  mkdir ./logs
fi

if [ ! -d "./temp" ]; then
  mkdir ./temp
fi

#export JAVA_COMMAND="/usr/local/ofd/jdk1.7.0_25/bin/java"
export JAVA_COMMAND="java"

# 如果是32位系统,就一定是32位JDK,如果是64位系统,需要判断jdk的位数
bit=$(getconf LONG_BIT)

echo "OS is ${bit} bit"

if [ ${bit} = "32" ] ; then
	bit="x86"
else
	${JAVA_COMMAND} -Xmx3000m -version
	if [ $? -eq 0 ]; then
		bit="x64"
	else
		bit="x86"
	fi
fi

echo "Java command is ${JAVA_COMMAND}"

echo "Java is ${bit}, select ${bit} config running..."

./wrapper/${bit}/wrapper -c wrapper.conf

