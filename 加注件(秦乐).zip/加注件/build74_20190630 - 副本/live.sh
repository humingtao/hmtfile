#!/bin/bash 
# chmod +x ./live.sh
# nohup ./live.sh >/dev/null 2>&1 &

if [ ! -d "./logs" ]; then
  mkdir ./logs
fi

if [ ! -d "./temp" ]; then
  mkdir ./temp
fi

java -Xmx1024m -Xms1024m -XX:PermSize=128m -XX:MaxPermSize=256m -noverify -classpath .:./*:./lib/*:./lib/core/*:./lib/business/*:./lib/runtime/*:./lib/runtime/log/*:./lib/mq/*:./lib/optional/*:./lib/extension/* -Djava.awt.headless=true -Djava.io.tmpdir=./temp com.suwell.ofd.convert.agent.AgentMain http://172.16.88.52:8080/convert-issuer/
