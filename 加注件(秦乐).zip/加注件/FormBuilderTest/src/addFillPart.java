﻿
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;

import com.suwell.local.convert.PacketMain;
import com.suwell.ofd.custom.agent.ConvertException;
import com.suwell.ofd.custom.agent.HTTPAgent;
import com.suwell.ofd.custom.wrapper.Const;
import com.suwell.ofd.custom.wrapper.Packet;
import com.suwell.ofd.custom.wrapper.Const.EnvelopeMeta;
import com.suwell.ofd.custom.wrapper.Const.EnvelopePerm;
import com.suwell.ofd.custom.wrapper.Const.Meta;
import com.suwell.ofd.custom.wrapper.Const.PackType;
import com.suwell.ofd.custom.wrapper.Const.PageLayout;
import com.suwell.ofd.custom.wrapper.Const.Perm;
import com.suwell.ofd.custom.wrapper.Const.Target;
import com.suwell.ofd.custom.wrapper.Const.View;
import com.suwell.ofd.custom.wrapper.PackException;
import com.suwell.ofd.custom.wrapper.model.CA;
import com.suwell.ofd.custom.wrapper.model.CipherProvider;
import com.suwell.ofd.custom.wrapper.model.Common;
import com.suwell.ofd.custom.wrapper.model.MarkPosition;
import com.suwell.ofd.custom.wrapper.model.Pair;
import com.suwell.ofd.custom.wrapper.model.SealInfo;
import com.suwell.ofd.custom.wrapper.model.SignInfo;
import com.suwell.ofd.custom.wrapper.model.Template;
import com.suwell.ofd.custom.wrapper.model.TextInfo;

public class addFillPart {
	public static void main(String args[]) throws PackException, IOException, ConvertException {
		addFillPart a = new addFillPart();
		//a.temp2ofd();
		a.ofdFilePart();

	}

	HTTPAgent ha = new HTTPAgent("http://127.0.0.1:8080/convert-issuer");

	// 证照生成
	private void temp2ofd() {
		Packet w = new Packet("Native.parser", Const.Target.OFD);
		try {
			// 1.模板和数据合成证照
			InputStream temp1 = new FileInputStream(new File("D:\\ofd\\formbuilder\\formbuilder.ofd"));
			InputStream data1 = new FileInputStream(new File("D:\\ofd\\formbuilder\\formbuilder.xml"));
			Template t1 = new Template("单页套转示例", temp1, data1);
			w.data(t1);

			// 2.盖电子签章
			SealInfo info = new SealInfo(SealInfo.NativeType.Normal, "1", 10, 10, 45, 45, "123456", 0);
			w.seal("Suwell", null, info);

			// 3.加锁定签名
			SignInfo s1 = new SignInfo("1", "123456");
			w.signature("Suwell", true, s1);// 锁定true

			ha.convert(w, new FileOutputStream("D://ofd/2_c999.ofd"));

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				w.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	// 证照加注
	private void ofdFilePart() throws PackException, IOException, ConvertException {
		Packet w = new Packet("Native.parser", Const.Target.OFD);
		Common c = new Common("test", "ofd", new FileInputStream("D://ofd/2_c999.ofd"));
		w.file(c);

		SignInfo si = new SignInfo("1", "123456", new TextInfo("demo888", "微软雅黑", 16, "#FF00FF"),
				new MarkPosition(10, 20, 10, 10, new int[] { 1, 2 }), true, true);
		w.signature("Suwell", false, si);// 加注FALSE
		SignInfo s1 = new SignInfo("1", "123456");
		w.signature("Suwell", true, s1);// 锁定true

		ha.convert(w, new FileOutputStream("D://ofd//2_c98888.ofd"));
		System.out.println("finish");
	}

}
